from flask import Flask, render_template, request, jsonify, redirect
import pandas as pd
from model import *
from model_v3 import *
from  model_v2 import *

#print(parent_list)
#parent_list = [semih, alperen, furkan , elif_dogan]


app = Flask(__name__)



@app.route('/anasayfa',methods= ['GET', 'POST'])
def main_page():
    if request.method == 'POST':
        input = request.form['text']

        with open('readme.txt', 'a') as f:
             f.writelines(input + ', ')

        input = spelling(input)


        listToStr = ' '.join([str(elem) for elem in input])
        listToStr += '\n'

        with open('readme.txt', 'a') as f:
             f.writelines(listToStr)


        grouped_df = get_scores(input)
        
        parent_list = []
        lenght = len(grouped_df)
        if lenght >5:
            lenght = 5
        for matched_user_id in range(lenght):

            parent_list.append(get_user(matched_user_id,grouped_df))
        #print(parent_list)
        #parent_list = [semih, alperen, furkan , elif_dogan]
        return render_template('index.html', parent_list = parent_list)
        #return redirect("/main", parent_list = pare)

    return render_template('index1.html') 




@app.route('/anasayfa2',methods= ['GET', 'POST'])
def main_page2():
    if request.method == 'POST':
        name = request.form['text']
        print(name)
        power_bi = get_score(name)

        parent_list = []
        for matched_user_id in power_bi:

            parent_list.append(get_user(matched_user_id))
        #print(parent_list)
        #parent_list = [semih, alperen, furkan , elif_dogan]
        return render_template('index.html', parent_list = parent_list)
        #return redirect("/main", parent_list = pare)

    return render_template('index1.html') 



if __name__ == '__main__':
    app.run(port=8001, debug=True)
