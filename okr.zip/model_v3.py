import pandas as pd
import numpy as np
import re #özel karakterleri kaldırmak için
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import words,stopwords
from symspellpy import SymSpell, Verbosity
from nltk.tokenize import word_tokenize
import random


nltk.download('punkt')
nltk.download("words")
nltk.download('stopwords')

correct_words = set(words.words())
stop_words = set(stopwords.words('english'))

def suggested_corrections(word):
    sym_spell = SymSpell(max_dictionary_edit_distance=2, prefix_length=7)
    sym_spell.create_dictionary("words2.txt")

    suggestions = sym_spell.lookup(word, Verbosity.CLOSEST, max_edit_distance=2)

    if suggestions:
        return suggestions[0].term
    else:
        return word


def spelling(searched_term):
#Regularization of inputs
    input_query = searched_term.lower().split(' ')
    for i in range(len(input_query)):
        input_query[i] = re.sub(r'[^a-zA-Z0-9\s]', '', input_query[i])

    input_query = [word for word in input_query if word.lower() not in stop_words]



    suggestions = {}
    corrected_word_list = []

    for word in input_query:
        if word.lower() not in correct_words:
            correction = suggested_corrections(word)
            suggestions[word] = correction
            corrected_word_list.append(correction)
        else:
            suggestions[word] = word
            corrected_word_list.append(word)


    if 'power' and 'bi' in corrected_word_list:
        corrected_word_list.remove('power')
        corrected_word_list.extend(['powerbi','power bi'])
    elif 'powerbi' in corrected_word_list:
        corrected_word_list.append('power bi')
    elif 'datascience' in corrected_word_list:
        corrected_word_list.extend(['data','science','data science'])
    elif 'data' and 'science' in corrected_word_list:
        corrected_word_list.append('data science')
    elif 'power' and 'apps' in corrected_word_list:
        corrected_word_list.remove('power')
        corrected_word_list.extend(['powerapps','power apps'])
    elif 'data' and 'scientist' in corrected_word_list:
        corrected_word_list.append('data scientist')
    elif 'datascientist' in corrected_word_list:
        corrected_word_list.extend(['data','scientist','data scientist'])
    elif 'power' and 'apps' in corrected_word_list:
        corrected_word_list.remove('power')
        corrected_word_list.append('powerapps')
    elif 'powerapps' in corrected_word_list:
        corrected_word_list.extend(['power apps'])
    #elif 'powerautomate' in corrected_word_list:
    #    corrected_word_list.extend(['power apps'])
    #elif 'processmining' in corrected_word_list:
    #    corrected_word_list.extend(['power apps'])

    return corrected_word_list

