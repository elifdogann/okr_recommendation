import pandas as pd
import math
import re
from collections import Counter


data = pd.read_csv('data/datav3.csv')


WORD = re.compile(r"\w+")


def get_cosine(vec1, vec2):
    intersection = set(vec1.keys()) & set(vec2.keys())
    numerator = sum([vec1[x] * vec2[x] for x in intersection])

    sum1 = sum([vec1[x] ** 2 for x in list(vec1.keys())])
    sum2 = sum([vec2[x] ** 2 for x in list(vec2.keys())])
    denominator = math.sqrt(sum1) * math.sqrt(sum2)

    if not denominator:
        return 0.0
    else:
        return float(numerator) / denominator


def text_to_vector(text):
    words = WORD.findall(text)
    return Counter(words)



def get_score(input):

    vector1 = text_to_vector(input.lower())

    input2 = {}
    for i in range(len(data)):
        try:    
            content = ''
            skills = data.loc[i]['Qualifications'].split(',')
            scores = data.loc[i]['Qualification Score(0-10)'].split(',')

            for skill in range(len(skills)):
                skills[skill] = skills[skill]  + ' ,'
                content +=  skills[skill]* int(float(scores[skill]))
            #print(data.loc[i]['E-Mail'])
            vector2 = text_to_vector(content.lower())
            cosine = get_cosine(vector1, vector2)

            #print("Cosine:", cosine)
            if (cosine != 0.0):
                input2[data.loc[i]['E-Mail']] = cosine
                
                scores_sorted = sorted(input2.items(), key=lambda x:x[1], reverse=True)[:5]
                #print(scores_sorted)
                matched_users_id = []
                for person in scores_sorted:
                    matched_users_id.append(data.loc[data['E-Mail'] == str(person[0])].index[0])
            
        except:
            pass
        
    return matched_users_id




data = pd.read_csv('data/datav2.csv')

def get_user(user_id):
    user_name = data.iloc[user_id]['Person']
    about_me = data.iloc[user_id]['Introduction(with 3-4 sentences)']
    email = data.iloc[user_id]['E-Mail']
    qualifications = data.iloc[user_id]['Qualifications'].split(',')
    shape_team = data.iloc[user_id]['Shape'] #+ '/' + data.iloc[user_id]['BSH Team']
    position = data.iloc[user_id]['Position']

    user = {'position': position,
         'user_name':user_name,
    'email': email,
        'about_me': about_me, 
                'email': email,
                'qualifications': qualifications,
                'team': shape_team,
                'profile_pic': ''}
    
    return user

semih = get_user(0)
semih['profile_pic'] = 'https://media.licdn.com/dms/image/D4D03AQFPrjyT4zBStg/profile-displayphoto-shrink_200_200/0/1688899668703?e=1698883200&v=beta&t=eUcg_WDoUykvxNqDnPHdtsj9iHgqbEfrEc5LMRNzj5I'
alperen = get_user(2)
alperen['profile_pic'] = 'https://media.licdn.com/dms/image/C4D03AQGngcv2jMj9Kg/profile-displayphoto-shrink_200_200/0/1585407855360?e=1698883200&v=beta&t=YRmY32-Y6DtSlf2jByl_RHp3fAIKH9yYTLX-lTz2ph0'
furkan = get_user(3)
furkan['profile_pic'] = 'https://media.licdn.com/dms/image/C4E03AQF4NAsDfFpqMw/profile-displayphoto-shrink_200_200/0/1517504274626?e=1698883200&v=beta&t=tjPLyMvpQe_zsvCeoZpYopU4mdBMJjQHTsa7NXRGM30'
elif_dogan = get_user(1)
elif_dogan['profile_pic'] = 'https://media.licdn.com/dms/image/D4D03AQHfM2fce4e2Vw/profile-displayphoto-shrink_200_200/0/1663137534638?e=1698883200&v=beta&t=A_aHZLmdZC8trW5nUi29L5KbL9pltun9hKGmYziFmRU'



#power_bi = get_score('Power BI')
#print(power_bi)


#parent_list = [semih, alperen, furkan , elif_dogan]
#parent_list = []
#for matched_user_id in power_bi:

    #parent_list.append(get_user(matched_user_id))

#print(parent_list)

#parent_list = [semih, alperen, furkan , elif_dogan]