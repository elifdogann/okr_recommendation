import pandas as pd
import math
import re
from collections import Counter

df = pd.read_excel('skillmatrixdata_080923.xlsx').drop(['Unnamed: 0'], axis = 1)


df['Qualifications'] = df['Qualifications'].str.split(',')
df['Qualification Score(0-10)'] = df['Qualification Score(0-10)'].str.split(',')
columns_to_explode = ['Qualifications','Qualification Score(0-10)']
exploded_df = df.explode(columns_to_explode)


exploded_df['Qualification Score(0-10)'] = exploded_df['Qualification Score(0-10)'].astype(float).round()
exploded_df['new_qualifications'] = exploded_df['Qualifications'].str.replace(' ',',')
exploded_df['new_qualifications'] = exploded_df['new_qualifications'].str.lower()
exploded_df['new_position'] = exploded_df['Position'].str.replace(' ',',')
exploded_df['new_position'] = exploded_df['new_position'].str.lower()


#print(exploded_df.head(5))


#input  = 'Data Scientist'


def get_scores(input_query):

    #input_query = input_query.lower().split(' ')

    exploded_df['Score_Qualification'] = exploded_df['new_qualifications'].apply(lambda x: sum(x.count(item.strip()) for item in input_query))
    exploded_df['Position_Score'] = exploded_df['new_position'].apply(lambda x: sum(x.count(item.strip()) for item in input_query))

    last_df = exploded_df[exploded_df['Score_Qualification']!=0]
    last_df['Last_Score'] = last_df['Qualification Score(0-10)'] + last_df['Score_Qualification'] + last_df['Position_Score']

    grouped_df = last_df.groupby('Person')['Last_Score'].agg('sum')
    grouped_df = grouped_df.reset_index()
    grouped_df = grouped_df.sort_values('Last_Score', ascending=False)

    return grouped_df


#grouped_df = get_scores(input)


def get_user(user_id, grouped_df):


    data = df[df['Person'] == grouped_df.iloc[user_id]['Person']].iloc[0]


    user_name = data['Person']
    about_me = data['CV(with 3-4 sentences)']
    email = data['E-Mail']
    qualifications = data['Qualifications']
    shape_team = data['Shape'] #+ '/' + data.iloc[user_id]['BSH Team']
    position = data['Position']

    user = {'position': position,
         'user_name':user_name,
    'email': email,
        'about_me': about_me, 
                'email': email,
                'qualifications': qualifications,
                'team': shape_team,
                'profile_pic': ''}
    
    return user


